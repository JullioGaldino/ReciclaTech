package com.reciclatech.cadastroFuncionario.model;

import jakarta.persistence.*;

@Entity
@Table(name = "registro_de_saida")
public class Saida {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "registroId", nullable = false, unique = true)
    private Long registroId;

    @Column(nullable = false)
    private String Funcionario;

    @Column(nullable = false)
    private Float Valor;

    @Column(nullable = false, unique = true)
    private String Form_de_Pg;

    @Column(nullable = false)
    private String Desc_produto;

    public Long getRegistroId() {
        return registroId;
    }

    public void setRegistroId(Long registroId) {
        this.registroId = registroId;
    }

    public String getFuncionario() {
        return Funcionario;
    }

    public void setFuncionario(String funcionario) {
        Funcionario = funcionario;
    }

    public Float getValor() {
        return Valor;
    }

    public void setValor(String valor) {
        this.Valor = Float.valueOf(valor);
    }

    public String getForm_de_Pg() {
        return Form_de_Pg;
    }

    public void setForm_de_Pg(String form_de_Pg) {
        this.Form_de_Pg = form_de_Pg;
    }

    public   String getDesc_produto() {
        return Desc_produto;
    }

    public void setDesc_produto(String desc_produto) {
        this.Desc_produto = desc_produto;
    }
}
