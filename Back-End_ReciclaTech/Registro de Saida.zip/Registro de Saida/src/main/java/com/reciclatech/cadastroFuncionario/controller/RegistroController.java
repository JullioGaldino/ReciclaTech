package com.reciclatech.cadastroFuncionario.controller;

import com.reciclatech.cadastroFuncionario.model.Saida;
import com.reciclatech.cadastroFuncionario.service.RegistroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/registro_de_saida")
public class RegistroController {

    @Autowired
    private RegistroService registroService;


    @PostMapping
    public ResponseEntity<Saida> RegistrarSaida(@RequestBody Saida saida) {
        Saida salvo = registroService.salvarRegistro(saida);
        return ResponseEntity.status(201).body(salvo);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Saida> getUsuarioById(@PathVariable Long id) {
        Optional<Saida> usuario = registroService.buscarPorId(id);
        return usuario.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

}

