package com.reciclatech.cadastroFuncionario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistroSaidaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistroSaidaApplication.class, args);
	}

}
