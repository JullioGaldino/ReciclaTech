package com.reciclatech.cadastroFuncionario.service;

import com.reciclatech.cadastroFuncionario.model.Saida;
import com.reciclatech.cadastroFuncionario.repository.RegistroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RegistroService {

    @Autowired
    private RegistroRepository registroRepository;

    public Saida salvarRegistro(Saida saida) {
        return registroRepository.save(saida);
    }

    public Optional<Saida> buscarPorId(Long id) {
        return registroRepository.findById(id);
    }

}
